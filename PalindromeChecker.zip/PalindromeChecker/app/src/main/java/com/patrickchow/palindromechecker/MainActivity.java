package com.patrickchow.palindromechecker;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText input;
    Button   button;
    TextView message;

    //Checks to see if the word is a palindrome or not.
    public String isPalindrome(String word){

        //Ignores capitalization, punctuation, and spaces
        word = word.toLowerCase().replaceAll("\\W", "");

        int forward = 0;
        int backward = word.length()-1;
        boolean flag = true;

        while(forward < backward) {
            char forwardChar = word.charAt(forward++);
            char backwardChar = word.charAt(backward--);
            if (forwardChar != backwardChar)
                flag = false;
        }
        return flag ? "Yes it is a palindrome.":"No it isn't a palindrome";
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        input = findViewById(R.id.inputID);
        button = findViewById(R.id.palindromeBtnID);
        message = findViewById(R.id.textViewID);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //converts EditText into a string.
                String word = input.getText().toString();
                String outcome = isPalindrome(word);
                message.setText(outcome);
            }
        });
    }
}
